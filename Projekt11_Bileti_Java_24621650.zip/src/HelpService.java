public class HelpService { public String text(){return "open close save saveas help addevent freeseats book unbook buy bookings check report exit";} }
