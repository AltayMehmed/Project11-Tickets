import java.util.*;
public class TicketRegistry {
    private final List<Ticket> tickets=new ArrayList<>();
    public void add(Ticket t){tickets.add(t);} public List<Ticket> all(){return tickets;}
    public Ticket find(String code){for(Ticket t:tickets)if(t.getCode().equalsIgnoreCase(code))return t;return null;}
    public boolean occupied(String performance,int row,int seat){for(Ticket t:tickets)if(t.getPerformance().equals(performance)&&t.getRow()==row&&t.getSeat()==seat)return true;return false;}
    public int sold(String performance){int n=0;for(Ticket t:tickets)if(t.getPerformance().equals(performance)&&t.getStatus()==TicketStatus.SOLD)n++;return n;}
    public void remove(Ticket t){tickets.remove(t);}
}
