public class CommandLoop {
    private final CinemaSystem system;
    private final Console console = new Console();
    public CommandLoop(CinemaSystem system) { this.system = system; }
    public void run() {
        console.print("Билетна система - ФН 24621650");
        while (true) {
            String line = console.read();
            if (line.equalsIgnoreCase("exit")) break;
            try { console.print(system.execute(line)); }
            catch (Exception e) { console.print("ERROR: " + e.getMessage()); }
        }
    }
}
