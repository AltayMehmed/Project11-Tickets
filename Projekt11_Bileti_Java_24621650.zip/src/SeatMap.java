public class SeatMap {
    private final Hall hall;
    public SeatMap(Hall hall){this.hall=hall;}
    public boolean valid(int row,int seat){return hall.valid(row,seat);}
    public int total(){return hall.getRows()*hall.getSeats();}
}
