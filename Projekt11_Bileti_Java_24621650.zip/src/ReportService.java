import java.util.*;
public class ReportService {
    public String report(TicketRegistry r,String from,String to){Map<String,Integer> m=new TreeMap<>();for(Ticket t:r.all())if(t.getStatus()==TicketStatus.SOLD)m.put(t.getPerformance(),m.getOrDefault(t.getPerformance(),0)+1);StringBuilder s=new StringBuilder();for(var e:m.entrySet())s.append(e.getKey()).append(" -> ").append(e.getValue()).append(" sold\n");return s.length()==0?"Няма продадени билети.":s.toString();}
}
