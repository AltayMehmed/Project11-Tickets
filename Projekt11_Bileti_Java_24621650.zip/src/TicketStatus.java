public enum TicketStatus { RESERVED,SOLD }
