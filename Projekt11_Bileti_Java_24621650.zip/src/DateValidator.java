public class DateValidator { public static void check(String d){if(!d.matches("\\d{4}-\\d{2}-\\d{2}"))throw new IllegalArgumentException("Датата трябва да е YYYY-MM-DD.");} }
