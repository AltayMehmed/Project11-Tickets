public class Seat { public final int row, number; public Seat(int row,int number){this.row=row;this.number=number;} public String toString(){return row+"/"+number;} }
