public class FileManager {
    private String activeFile; public String getActiveFile(){return activeFile;} public void setActiveFile(String f){activeFile=f;} public void clear(){activeFile=null;} public boolean open(){return activeFile!=null;}
}
