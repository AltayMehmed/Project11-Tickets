public class Command {
    public final CommandType type;
    public final String[] args;
    public Command(CommandType type, String[] args) { this.type = type; this.args = args; }
}
