public class Ticket {
    private final String code,performance; private final int row,seat; private TicketStatus status; private String note;
    public Ticket(String code,String performance,int row,int seat,TicketStatus status,String note){this.code=code;this.performance=performance;this.row=row;this.seat=seat;this.status=status;this.note=note;}
    public String getCode(){return code;} public String getPerformance(){return performance;} public int getRow(){return row;} public int getSeat(){return seat;}
    public TicketStatus getStatus(){return status;} public void setStatus(TicketStatus s){status=s;} public String getNote(){return note;}
    public String toString(){return code+" | "+performance+" | "+row+"/"+seat+" | "+status+(note.isEmpty()?"":" | "+note);}
}
