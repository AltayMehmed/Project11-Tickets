public class Performance {
    private final String name,date,hall;
    public Performance(String name,String date,String hall){this.name=name;this.date=date;this.hall=hall;}
    public String getName(){return name;} public String getDate(){return date;} public String getHall(){return hall;}
    public String key(){return name+"|"+date+"|"+hall;}
}
