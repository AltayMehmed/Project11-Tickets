public class CinemaSystem {
    private final CommandParser parser=new CommandParser(); private final FileManager files=new FileManager(); private final XmlRepository xml=new XmlRepository(); private final HelpService help=new HelpService(); private final ReportService report=new ReportService(); private final TicketRegistry tickets=new TicketRegistry();
    private boolean opened=false;
    public String execute(String line) throws Exception {
        Command c=parser.parse(line); if(c.type==CommandType.HELP)return help.text(); if(c.type==CommandType.EXIT)return "До скоро.";
        if(c.type==CommandType.OPEN){InputValidator.args(c.args,1); tickets.all().clear(); TicketRegistry loaded=xml.load(c.args[0]); tickets.all().addAll(loaded.all()); files.setActiveFile(c.args[0]); opened=true; return "Отворен файл: "+c.args[0];}
        if(c.type==CommandType.CLOSE){opened=false;files.clear();tickets.all().clear();return "Файлът е затворен.";}
        if(!opened)throw new CommandException("Няма отворен файл.");
        switch(c.type){
            case SAVE -> {xml.save(files.getActiveFile(),tickets);return "Записано.";}
            case SAVE_AS -> {InputValidator.args(c.args,1);xml.save(c.args[0],tickets);files.setActiveFile(c.args[0]);return "Записано в "+c.args[0];}
            case ADD_EVENT -> {InputValidator.args(c.args,5);DateValidator.check(c.args[1]);return "Добавено представление: "+c.args[0];}
            case FREE_SEATS -> {InputValidator.args(c.args,3);int rows=10,seats=10;int free=0;String p=c.args[0]+"|"+c.args[1]+"|"+c.args[2];for(int r=1;r<=rows;r++)for(int s=1;s<=seats;s++)if(!tickets.occupied(p,r,s))free++;return "Свободни места: "+free;}
            case BOOK,BUY -> {InputValidator.args(c.args,4);String p=c.args[0]+"|"+c.args[1]+"|"+c.args[2];int row=InputValidator.number(c.args[3]);int seat=c.args.length>4?InputValidator.number(c.args[4]):1;if(tickets.occupied(p,row,seat))throw new CommandException("Мястото е заето.");Ticket t=new Ticket(TicketCodeGenerator.next(),p,row,seat,c.type==CommandType.BOOK?TicketStatus.RESERVED:TicketStatus.SOLD,c.args.length>5?c.args[5]:"");tickets.add(t);return t.toString();}
            case UNBOOK -> {InputValidator.args(c.args,4);String p=c.args[0]+"|"+c.args[1]+"|"+c.args[2];int row=InputValidator.number(c.args[3]);int seat=c.args.length>4?InputValidator.number(c.args[4]):1;Ticket t=find(p,row,seat);if(t==null||t.getStatus()!=TicketStatus.RESERVED)throw new CommandException("Няма резервация.");tickets.remove(t);return "Резервацията е отказана.";}
            case BOOKINGS -> {StringBuilder s=new StringBuilder();for(Ticket t:tickets.all())if(t.getStatus()==TicketStatus.RESERVED)s.append(t).append('\n');return s.length()==0?"Няма резервации.":s.toString();}
            case CHECK -> {InputValidator.args(c.args,1);Ticket t=tickets.find(c.args[0]);return t==null?"Невалиден билет.":t.toString();}
            case REPORT -> {return report.report(tickets,c.args.length>0?c.args[0]:"",c.args.length>1?c.args[1]:"");}
            default -> {throw new CommandException("Непозната команда.");}
        }
    }
    private Ticket find(String p,int row,int seat){for(Ticket t:tickets.all())if(t.getPerformance().equals(p)&&t.getRow()==row&&t.getSeat()==seat)return t;return null;}
}
