public class Application {
    public void start() {
        new CommandLoop(new CinemaSystem()).run();
    }
}
