public class Hall {
    private final String name; private final int rows, seats;
    public Hall(String name,int rows,int seats){this.name=name;this.rows=rows;this.seats=seats;}
    public String getName(){return name;} public int getRows(){return rows;} public int getSeats(){return seats;}
    public boolean valid(int row,int seat){return row>=1&&row<=rows&&seat>=1&&seat<=seats;}
}
