public class CommandParser {
    public Command parse(String line) {
        String[] p = line.trim().split("\\s+");
        if (p.length == 0 || p[0].isEmpty()) return new Command(CommandType.UNKNOWN,new String[0]);
        String c=p[0].toLowerCase();
        CommandType t=switch(c){
            case "open"->CommandType.OPEN; case "close"->CommandType.CLOSE; case "save"->CommandType.SAVE;
            case "saveas","save-as"->CommandType.SAVE_AS; case "help"->CommandType.HELP;
            case "addevent"->CommandType.ADD_EVENT; case "freeseats"->CommandType.FREE_SEATS;
            case "book"->CommandType.BOOK; case "unbook"->CommandType.UNBOOK; case "buy"->CommandType.BUY;
            case "bookings"->CommandType.BOOKINGS; case "check"->CommandType.CHECK; case "report"->CommandType.REPORT;
            case "exit"->CommandType.EXIT; default->CommandType.UNKNOWN;};
        String[] a=new String[Math.max(0,p.length-1)]; System.arraycopy(p,1,a,0,a.length);
        return new Command(t,a);
    }
}
