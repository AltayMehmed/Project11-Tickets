public class InputValidator {
    public static int number(String s){try{return Integer.parseInt(s);}catch(Exception e){throw new IllegalArgumentException("Невалидно число: "+s);}}
    public static void args(String[] a,int n){if(a.length<n)throw new IllegalArgumentException("Недостатъчно аргументи.");}
}
