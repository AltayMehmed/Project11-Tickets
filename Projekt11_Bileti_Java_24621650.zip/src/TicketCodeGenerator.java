import java.util.UUID;
public class TicketCodeGenerator { public static String next(){return UUID.randomUUID().toString().substring(0,8).toUpperCase();} }
