import java.util.Scanner;
public class Console {
    private final Scanner scanner = new Scanner(System.in);
    public String read() { System.out.print("> "); return scanner.nextLine(); }
    public void print(String text) { System.out.println(text); }
}
